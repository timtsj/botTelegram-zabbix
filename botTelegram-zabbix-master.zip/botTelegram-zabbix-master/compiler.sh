rm *.pyc
python -m compileall -f .

